# Lambda 1 (start_textract_lambda): Triggered by S3 upload. Starts Textract job with SNS notification.
# Lambda 2 (process_textract_result_lambda): Triggered by SNS, fetches the Textract job results and logs extracted text.



import boto3
import json

textract=boto3.client('textract')

def lambda_handler(event ,context):
    print("Recieved JSON", json.dumps(event))

# Extract bucket and file name
    bucket=event['Records'][0]['s3']['bucket']['name']
    document_key= ['Records'][0]['s3']['object']['key']

  # Start Textract analysis job
    response=textract.start_document_analysis(
        DocumentLocation=
        {
            'S3object':
            {
                'Bucket':bucket,
                'Name': document_key,
            },          
            'FeatureTypes': ['TABLES', 'FORMS'],
            'NotificationChannel' :{
            'RoleArn': 'arn:aws:iam::221082183774:role/TextractServiceRole',
            'SNSTopicArn': 'arn:aws:sns:ap-south-1:221082183774:TextractTopic'
            },
        }
    )
    job_id=response['Job ID']
    print(f"Started Textract job with ID: {job_id}")

    return {
        'statusCode': 200,
        'body': json.dumps(f"Started Textract job: {job_id}")
    }